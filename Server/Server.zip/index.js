const express = require("express");
const app = express();
const mysql = require("mysql2");
const cors = require("cors");
const bcrypt = require("bcrypt");
const res = require("express/lib/response");
const saltRounds = 10;
const { Sequelize } = require('sequelize');

{/*Conexão Com o banco de dados */}

const db = mysql.createPool({
  host: "localhost",
  user: "escabjba_user_login_node_jwt",
  password: "?Yp4]ccvQaI1",
  database: "escabjba_login_node_jwt",
});

app.use(express.json());
app.use(cors());

app.post("/register", (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  db.query("SELECT * FROM usuarios WHERE email = ?", [email], (err, result) => {
    if (err) {
      res.send(err);
    }
    if (result.length == 0) {
      bcrypt.hash(password, saltRounds, (err, hash) => {
        db.query(
          "INSERT INTO usuarios (email, password) VALUE (?,?)",
          [email, hash],
          (error, response) => {
            if (err) {
              res.send(err);
            }

            res.send({ msg: "Usuario registrado correctamente" });
          }
        );
      });
    } else {
      res.send({ msg: "Correo electrónico ya registrado" });
    }
  });
});

{/*Verificação de login*/}

app.post("/login", (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  db.query("SELECT * FROM usuarios WHERE email = ?", [email], (err, result) => {
    if (err) {
      res.send(err);
    }
    if (result.length > 0) {
      bcrypt.compare(password, result[0].password, (error, response) => {
        if (error) {
          res.send(error);
        }
        if (response === true) {
          res.send(response)
          
        } else {
          res.send({ msg: "Correo o contraseña incorrecta" });
        }
      });
    } else {
      res.send({ msg: "Usuario no registrado" });
    }
  });
});


/* Configs do CRUD
app.post("/insert", (req, res) => {
  const { name } = req.body;
  const { cost } = req.body;
  let SQL = "INSERT INTO items (name,cost) VALUES (?,?)"

    db.query(SQL,[name,cost], (err, result) => {
        console.log(err);
   }) 
});

app.get("/get", (req, res) => {
    let SQL = "SELECT * FROM items"

    db.query(SQL, (err, result) => {
        if (err) console.log(err);
        else res.send(result);
    });
});

app.get("/getCards/:nome", (req,res) => {
  const nome = req.params.nome;
  let sql = `SELECT * FROM items WHERE name LIKE '${nome}%'`;
  db.query(sql, [nome],(err, result) => {
    if (err) {
      console.log(err);
    }else {
      res.send(result);
    }
  })
});

app.put("/edit", (req,res)=>{
    const { id } = req.body;
    const { name } = req.body;
    const { cost } = req.body;

    let SQL = "UPDATE items SET name= ?, cost= ? WHERE iditems = ?";

    db.query(SQL, [name, cost, id], (err, result) => {
        if (err) console.log(err);
        else res.send(result);
    });

});

app.delete("/delete/:id",(req,res)=>{
        const {id} = req.params;
        let SQL = "DELETE FROM items WHERE iditems = ?";
         
        db.query(SQL,[id],(err, result) => {
            if (err) console.log(err);
            else res.send(result);
        });
}) */

//crud

const sequelize = new Sequelize('escabjba_login_node_jwt', 'escabjba_user_login_node_jwt', '?Yp4]ccvQaI1', {
  host: 'localhost',
  dialect: 'mysql'
});

sequelize.authenticate().then(() => console.log('Database connected...')).catch(err => console.error('Unable to connect to the database:', err));

const Categoria = sequelize.define('Categoria', {
  idcateg: {type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
  categoria: Sequelize.STRING
}, {timestamps: false});

const Marca = sequelize.define('Marca', {
  idmarca: {type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
  marca: Sequelize.STRING
}, {timestamps: false});

const Producto = sequelize.define('Producto', {
  idprod: {type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true},
  idcategoria: Sequelize.INTEGER,
  idmarca: Sequelize.INTEGER,
  descripcion: Sequelize.STRING,
  precio: Sequelize.DECIMAL(10, 2)
}, {timestamps: false});

Producto.belongsTo(Categoria, {foreignKey: 'idcategoria'});
Producto.belongsTo(Marca, {foreignKey: 'idmarca'});

sequelize.sync();

app.get('/productos', async (req, res) => {
  const productos = await Producto.findAll({ include: [Categoria, Marca]});
  res.send(productos);
});

app.post('/productos', async (req, res) => {
  const producto = await Producto.create(req.body);
  res.send(producto);
});

app.put('/productos/:idprod', async (req, res) => {
  const producto = await Producto.findByPk(req.params.idprod);
  await producto.update(req.body);
  res.send(producto);
});

app.delete('/productos/:idprod', async (req, res) => {
  const producto = await Producto.findByPk(req.params.idprod);
  await producto.destroy();
  res.send({message: 'Producto eliminado'});
});

app.get('/categoria', async (req, res) => {
  const categorias = await Categoria.findAll();
  res.send(categorias);
});

app.post('/categoria', async (req, res) => {
  const categoria = await Categoria.create(req.body);
  res.send(categoria);
});

app.put('/categoria/:idcateg', async (req, res) => {
  const categoria = await Categoria.findByPk(req.params.idcateg);
  await categoria.update(req.body);
  res.send(categoria);
});

app.delete('/categoria/:idcateg', async (req, res) => {
  const categoria = await Categoria.findByPk(req.params.idcateg);
  await categoria.destroy();
  res.send({message: 'Categoria eliminada'});
});

app.get('/marcas', async (req, res) => {
  const marcas = await Marca.findAll();
  res.send(marcas);
});

app.post('/marcas', async (req, res) => {
  const marca = await Marca.create(req.body);
  res.send(marca);
});

app.put('/marcas/:idmarca', async (req, res) => {
  const marca = await Marca.findByPk(req.params.idmarca);
  await marca.update(req.body);
  res.send(marca);
});

app.delete('/marcas/:idmarca', async (req, res) => {
  const marca = await Marca.findByPk(req.params.idmarca);
  await marca.destroy();
  res.send({message: 'Marca eliminada'});
});

// Endpoint para obtener todas las categorías
app.get('/categoria', async (req, res) => {
  const categorias = await Categoria.findAll();
  res.json(categorias);
});

// Endpoint para obtener todas las marcas
app.get('/marcas', async (req, res) => {
  const marcas = await Marca.findAll();
  res.json(marcas);
});


app.listen(3001, () => {
  console.log("rodando na porta 3001");
});

